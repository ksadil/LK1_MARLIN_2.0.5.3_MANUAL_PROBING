SlowSoftI2CMaster - fork
========================

Please use the original [SlowSoftI2CMaster](https://github.com/felias-fogg/SlowSoftI2CMaster),

this fork is only meant for [Mighty Board's](http://www.geeetech.com/wiki/index.php/Mighty_Board) digi pots.